class BooksController < ApplicationController
  def index
    @books = Book.all
    # コントローラでform_forヘルパに渡すための@bookオブジェクトを作成
    @book = Book.new
  end

  def show
    @book = Book.find(params[:id])
  end

  def new
    # new　画面は未使用
    # @book = Book.new
  end

  def create
    @book = Book.new(book_params)
    if @book.save
      # フラッシュメッセージ表示
      flash[:notice] = "Book was successfully created."
      # コントローラー経由で詳細画面表示
      redirect_to book_path(@book)
    else
      @books = Book.all
      # error 内容を表示のみ（この場合renderを使用する）
      #（redirect_toはcontroller経由のためerror内容が消えてしまう)
      #・render　　 ：ログインや入力形式に失敗した場合など　＝　ただエラーを表示させるだけ
      #・redirect_to：データ更新/削除が必要な場合　＝　controllerの処理が必要
      render :index
    end
  end

  def edit
    @book = Book.find(params[:id])
  end

  def update
    @book = Book.find(params[:id])
    if @book.update(book_params)
      # フラッシュメッセージ表示
      flash[:notice] = "Book was successfully updated."
      # コントローラー経由で詳細画面を再表示
      redirect_to book_path(@book)
    else
      # error 内容を表示のみ（この場合renderを使用する）
      #（redirect_toはcontroller経由のためerror内容が消えてしまう)
      #・render　　 ：ログインや入力形式に失敗した場合など　＝　ただエラーを表示させるだけ
      #・redirect_to：データ更新/削除が必要な場合　＝　controllerの処理が必要
      render :edit
    end
  end

  def destroy
    book = Book.find(params[:id])
    book.destroy
    # フラッシュメッセージ表示
    flash[:notice] = "Book was successfully destroyed."
    # コントローラー経由でINDEX画面再表示
    redirect_to books_path
  end

  # ---- ストロングパラメーター ---- #
  private
  def book_params
    params.require(:book).permit(:title, :body)
  end

end
